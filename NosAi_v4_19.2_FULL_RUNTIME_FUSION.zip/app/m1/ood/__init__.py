from .detector import OODDetector
