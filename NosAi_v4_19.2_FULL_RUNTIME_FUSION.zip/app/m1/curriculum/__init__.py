from .manager import CurriculumManager
